<?php 

// catch request
$router->run();